package CodeAlpha;

public class Student {

	String name;
	int grade;
	public Student(String n, int g) {////assigning  a value form the current object
		this.name = n;
		this.grade = g;
	}

}
